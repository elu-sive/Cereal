filter Find-AssemblyReference {
    param (
        [Parameter(Mandatory = $True, ValueFromPipelineByPropertyName = $True)]
        [Alias('FullName')]
        [String]
        [ValidateNotNullOrEmpty()]
        $Path,

        [Parameter(Mandatory = $True)]
        [String]
        [ValidateNotNullOrEmpty()]
        $Reference,

        [Int]
        [ValidateNotNullOrEmpty()]
        # How many functions to cap the deep search at
        $SearchLimit = 3000 
    )

    $FullPath = Resolve-Path $Path

    try {
        $Module = [dnlib.DotNet.ModuleDefMD]::Load($FullPath)
    } catch {
        return
    }

    $listMemberRefMD = $Module.GetType().GetFields('NonPublic, Instance') | ? { $_.Name -eq 'listMemberRefMD' }
    $MemberRefList = $listMemberRefMD.GetValue($Module)

    $GenericParamContext = New-Object -TypeName dnlib.DotNet.GenericParamContext

    $Methods = $Module.GetTypes() | %{ $_.Methods }

    $MemberRef = $null

    for ($i = 0; $i -lt $MemberRefList.Length; $i++) {
        $MemberRefDefinition = $MemberRefList.Item($i, $GenericParamContext)

        if($MemberRefDefinition.FullName -like "*$($Reference)*"){

            Write-Host "`n" $FullPath

            if ($Methods.Length -lt $SearchLimit){

                foreach ($Method in $Methods) {
                    $CleanName = $Method.FullName.Substring(0, $Method.FullName.IndexOf('('))

                    if ($Method.Body.Instructions | ?{ $_.Operand.FullName -like "*$($Reference)*" }) {
                        Write-Host "   |-$($Method.FullName)"

                        if ($Method.FullName -like "*UninitializePerformanceDLL*"){
                            $global:m = $Method
                            $global:b = $MemberRefDefinition
                        }

                        if ($Method.FullName -like "*ReadCache*"){
                            $global:m2 = $Method
                            $global:b2 = $MemberRefDefinition
                        }
                    }
                }

            }else{
                Write-Host "   |- [skipped due to size]"
            }

            break
        }
    }
}